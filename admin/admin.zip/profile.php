

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Profile</title>
</head>
<body>
	<div>
		<h1>Name</h1>
		<input type="textbox" name="Name" required>
	</div>
	<div>
		<h1>Contact Number</h1>
		<input type="textbox" name="Contact Number" required>
	</div>
	<div>
		<h1>email</h1>
		<input type="textbox" name="Email Id" required>
	</div>
</body>
</html>