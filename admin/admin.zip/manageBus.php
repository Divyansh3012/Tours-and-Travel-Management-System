<?php
	require "connect.php";
	
	   if(!isset($_SESSION['adlogin']))
	   {
	        session_start();
	    }
	    
	     
	$sql="select * FROM busdtls";
	$result= mysqli_query($conn,$sql);

	if (isset($_REQUEST['Bid_remove'])) 
	    {
	        $delete_sql="DELETE FROM busdtls WHERE Bid='".$_REQUEST['Bid_remove']."'";
	        $del_result=mysqli_query($conn,$delete_sql);

	?>

	<script type="text/javascript">window.location.href="manageBus.php"</script>

	<?php
	    }

?>

<html>
<head>
</head>
<body>
	<table border=3>
		<thead>
			<tr>
				<th>Details</th>
				<th>startin point</th>
				<th>Destination</th>
				<th>Arival Time</th>
				<th>Departure Time</th>
				<th>Adult Charges </th>
				<th>Child Charges</th>
				<th>Bus Details</th>
				<th>Delete</th>

			</tr>
		</thead>
	
<tbody>
	 <?php while ($row = mysqli_fetch_array($result,MYSQLI_BOTH)) { ?>
		<tr>

<td>
	<?php echo $row['Bid']; ?>
</td>
<td>
	<?php echo $row['Bfrom'];?>	
</td>
<td>
	<?php echo $row['Bto'];?>	
</td>
<td>
	<?php echo $row['B-Atime'];?>	
</td>
<td>
	<?php echo $row['B-Dtime'];?>
</td>
<td>
	<?php echo $row['Acharges'];?>
</td>
<td>
	<?php echo $row['Ccharges'];?>	
</td>
<td>
	<?php echo $row['Bdtls']; ?>
</td>
<td>
	<a href ="manageBus.php?Bid_remove=<?php echo $row["Bid"]?>"class="btn btn-danger">delete</a>
</td>
</tr>
<?php
}
?>
</tbody>
</table>
</body>
</html>
	