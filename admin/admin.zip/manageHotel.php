<?php
	require "connect.php";
	
	   if(!isset($_SESSION['adlogin']))
	   {
	        session_start();
	    }
	    
	     
	$sql="select * FROM hoteltbl";
	$result= mysqli_query($conn,$sql);

	if (isset($_REQUEST['hid_remove'])) 
	    {
	        $delete_sql="DELETE FROM hoteltbl WHERE hid='".$_REQUEST['hid_remove']."'";
	        $del_result=mysqli_query($conn,$delete_sql);

	?>

	<script type="text/javascript">window.location.href="manageHotel.php"</script>

	<?php
	    }

?>

<html>
<head>
</head>
<body>
	<table border=3>
		<thead>
			<tr>
				<th>Hotel ID</th>     <!-- <th> mean table header -->
				<th>Hotel Name</th>
				<th>Hotel Star</th>
				<th>Hotel Address</th>
				<th>City </th>
				<th>Pin</th>
				<th>Hotel Photo</th>
				<th>Delete</th>

			</tr>
		</thead>
	
<tbody>
	<?php while ($row = mysqli_fetch_array($result,MYSQLI_BOTH)) { ?>
		<tr>

<td>
	<?php echo $row['hid']; ?>
</td>
<td>
	<?php echo $row['hname'];?>	
</td>
<td>
	<?php echo $row['hstar'];?>	
</td>
<td>
jm	<?php echo $row['haddress'];?>	
</td>
<td>
	<?php echo $row['hcity'];?>
</td>
<td>
	<?php echo $row['hpin'];?>
</td>
<td>
	<?php echo $row['hphoto'];?>	
</td>
<td>
	<a href ="manageHotel.php?hid_remove=<?php echo $row["hid"]?>"class="btn btn-danger">delete</a>
</td>
</tr>
<?php
}
?>
</tbody>
</table>
</body>
</html>
	