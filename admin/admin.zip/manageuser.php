<?php
	require "connect.php";
	
	   if(!isset($_SESSION['adlogin']))
	   {
	        session_start();
	    }
	    
	     
	$sql="select * FROM usertbl";
	$result= mysqli_query($conn,$sql);

	if (isset($_REQUEST['uid_remove'])) 
	    {
	        $delete_sql="DELETE FROM usertbl WHERE uid='".$_REQUEST['uid_remove']."'";
	        $del_result=mysqli_query($conn,$delete_sql);

	?>

	<script type="text/javascript">window.location.href="manageuser.php"</script>

	<?php
	    }

?>

<html>
<head>
</head>
<body>
	<table border=3>
		<thead>
			<tr>
				<th>userID</th>
				<th>name</th>
				<th>email</th>
				<th>contact</th>
				<th>city</th>
				<th>address </th>
				<th>Delete</th>


			</tr>
		</thead>
	
<tbody>
	<?php while ($row = mysqli_fetch_array($result,MYSQLI_BOTH)) { ?>
		<tr>

<td>
	<?php echo $row['uid'];?>	
</td>
<td>
	<?php echo $row['uname'];?>	
</td>
<td>
	<?php echo $row['uemail'];?>	
</td>
<td>
	<?php echo $row['ucontact'];?>
</td>
<td>
	<?php echo $row['ucity'];?>
</td>
<td>
	<?php echo $row['uadd'];?>	
</td>
<td>
	<a href ="manageuser.php?uid_remove=<?php echo $row["uid"]?>"class="btn btn-danger">delete</a>
</td>
</tr>
<?php
}
?>
</tbody>
</table>
</body>
</html>
	