<?php
	require "connect.php";
	
	   if(!isset($_SESSION['adlogin']))
	   {
	        session_start();
	    }
	    
	     
	$sql="select * FROM traindtls";	

	
	$result= mysqli_query($conn,$sql);

	if (isset($_REQUEST['Tid_remove'])) 
	    {
	        $delete_sql="DELETE FROM traindtls WHERE Tid='".$_REQUEST['Tid_remove']."'";
	        $del_result=mysqli_query($conn,$delete_sql);

	?>

	<script type="text/javascript">window.location.href="manageTrains.php"</script>

	<?php
	    }

?>

<html>
<head>
</head>
<body>
	<table border=3>
		<thead>
			<tr>
				<th>Train ID</th>
				<th>startin point</th>
				<th>Destination</th>
				<th>Arival Time</th>
				<th>Departure Time</th>
				<th>Adult Charges </th>
				<th>Child Charges</th>
				<th>Train Details</th>
				<th>Delete</th>

			</tr>
		</thead>
	
<tbody>
	<?php while ($row = mysqli_fetch_array($result,MYSQLI_BOTH)) { ?>
		<tr>

<td>
	<?php echo $row['Tid']; ?>
</td>
<td>
	<?php echo $row['Tfrom'];?>	
</td>
<td>
	<?php echo $row['Tto'];?>	
</td>
<td>
	<?php echo $row['T-Atime'];?>	
</td>
<td>
	<?php echo $row['T-Dtime'];?>
</td>
<td>
	<?php echo $row['Acharges'];?>
</td>
<td>
	<?php echo $row['Ccharges'];?>	
</td>
<td>
	<?php echo $row['tdtls']; ?>
</td>
<td>
	<a href ="manageTrains.php?Tid_remove=<?php echo $row["Tid"]?>"class="btn btn-danger">delete</a>
</td>
</tr>
<?php
}
?>
</tbody>
</table>
</body>
</html>
	